# Flask Authentication & Authorization System

A production-ready Flask REST API with user registration, email verification, password reset, and Two-Factor Authentication (2FA).

## Features

- **User Registration & Login** - Secure authentication with session management
- **Email Verification** - 24-hour token-based email verification
- **Password Reset** - Secure token-based reset with 1-hour TTL
- **Two-Factor Authentication (2FA)** - RFC 6238 TOTP with QR codes
- **Password Hashing** - Argon2id (OWASP recommended)
- **Rate Limiting** - Protection against brute force attacks
- **SQLAlchemy ORM** - Clean database abstraction
- **SQLite/PostgreSQL** - SQLite for development, PostgreSQL for production
- **Docker Support** - Complete containerization with docker-compose
- **Comprehensive Tests** - 15 unit tests (70%+ coverage)

## Project Structure

```
login_python/
├── run.py                 # Application entry point
├── app/
│   ├── __init__.py       # App factory
│   ├── routes/           # API endpoints (auth, 2fa, user)
│   ├── services/         # Business logic (user, password, 2fa, email)
│   └── models/           # SQLAlchemy models
├── requirements.txt       # Dependencies
├── .env.example          # Configuration template
└── docker-compose.yml    # Docker orchestration
```

## Quick Start

```bash
# Setup
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Configure
cp .env.example .env  # Edit with your settings

# Run
python3 run.py
# App available at http://localhost:5001
```

### Environment Variables

```env
FLASK_ENV=development
SECRET_KEY=your-secret-key
DATABASE_URL=sqlite:///login.db
SMTP_SERVER=smtp.gmail.com
SMTP_USERNAME=your-email@gmail.com
SMTP_PASSWORD=app-password
PORT=5001
```

## API Endpoints

**Authentication:**
- `POST /api/register` - Create new user
- `POST /api/login` - Authenticate user
- `POST /api/logout` - Terminate session
- `POST /api/verify-email` - Verify email with token
- `POST /api/forgot-password` - Request password reset
- `POST /api/reset-password` - Reset password with token
- `GET /api/user-info` - Get current user profile
- `POST /api/change-password` - Change password

**Two-Factor Authentication:**
- `POST /api/2fa/setup` - Generate TOTP secret & QR code
- `POST /api/2fa/enable` - Enable 2FA
- `POST /api/2fa/verify` - Verify TOTP during login

## Testing

```bash
# Run all tests
python -m unittest tests.test_app -v
```

15 tests covering: password hashing, 2FA, email validation, registration, login, and authorization.

## Screenshots

### 1. Registration & Login
![Screenshot 1 - Registration](screenshots/Bildschirmfoto%202026-08-27%20um%2012.01.33.png)

### 2. User Dashboard
![Screenshot 2 - Email Verification](screenshots/Bildschirmfoto%202026-08-27%20um%2012.03.24.png)

### 3. Email Verification
![Screenshot 3 - User Dashboard](screenshots/Bildschirmfoto%202026-08-27%20um%2012.03.46.png)

### 4. Two-Factor Authentication Setup
![Screenshot 4 - 2FA Setup](screenshots/Bildschirmfoto%202026-08-27%20um%2012.07.45.png)

## Docker

```bash
# Build and start all services
docker-compose up -d

# View logs
docker-compose logs -f app

# Stop containers
docker-compose down
```

Services available at:
- App: http://localhost:5001
- Nginx: http://localhost

## License

MIT License

Contributions welcome! Please fork, create feature branch, add tests, and submit PR.
