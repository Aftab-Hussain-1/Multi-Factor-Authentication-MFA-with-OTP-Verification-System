# Email Verification Setup Guide

## Overview

This authentication system now includes **email verification** as a required step before users can login. When a user registers, they receive a verification email with a unique link. They must click the link to verify their email address before they can access their account.

---

## Features

✅ **Email Verification Flow:**
- User registers → verification email sent
- User clicks link in email → email verified
- User can now login
- Prevents unauthorized account creation

✅ **Security:**
- 24-hour token expiration
- Single-use tokens (cannot be reused)
- Tokens stored in database with user reference

✅ **User Experience:**
- Auto-verification when user clicks email link
- Friendly error messages
- Clear instructions in registration success message

---

## Setup Instructions

### Step 1: Configure Email Provider

Edit `.env` file and choose your email provider:

#### **Option A: Gmail SMTP (Recommended for Testing)**

```bash
EMAIL_PROVIDER=smtp
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=cst.staber@gmail.com
MAIL_PASSWORD=xxxx xxxx xxxx xxxx
MAIL_FROM_ADDR=cst.staber@gmail.com
MAIL_FROM_NAME=Login App
APP_URL=http://localhost:5000
```

**To get Gmail App Password:**
1. Go to https://myaccount.google.com/security
2. Enable "2-Step Verification"
3. Go to https://myaccount.google.com/apppasswords
4. Select "Mail" → "Mac" (or your device)
5. Google generates a 16-character password
6. Copy it (spaces are normal)

#### **Option B: SendGrid**

```bash
EMAIL_PROVIDER=sendgrid
SENDGRID_API_KEY=SG.xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
MAIL_FROM_ADDR=noreply@yourapp.com
MAIL_FROM_NAME=Login App
APP_URL=http://localhost:5000
```

#### **Option C: Outlook/Office 365**

```bash
EMAIL_PROVIDER=smtp
MAIL_SERVER=smtp-mail.outlook.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@outlook.com
MAIL_PASSWORD=your-password
MAIL_FROM_ADDR=your-email@outlook.com
MAIL_FROM_NAME=Login App
APP_URL=http://localhost:5000
```

### Step 2: Update APP_URL

Make sure `APP_URL` matches your deployment URL:
- **Local:** `http://localhost:5000`
- **Production:** `https://yourdomain.com`

---

## How It Works

### Registration Flow

```
1. User submits registration form
   ↓
2. Account created with is_verified=False
   ↓
3. EmailVerificationToken generated (24-hour expiry)
   ↓
4. Verification email sent to user
   ↓
5. User sees: "Please verify your email at [email]"
```

### Verification Flow

```
1. User clicks link in email
   ↓
2. Verification page loads (verify-email.html)
   ↓
3. Token validated and verified status updated
   ↓
4. User redirected to login page
   ↓
5. User can now login
```

### Login Flow

```
1. User enters credentials
   ↓
2. Password verified ✓
   ↓
3. Check: is_verified == True?
   ✗ NO  → Error: "Please verify your email before logging in"
   ✓ YES → Login successful
   ↓
4. Session created, redirect to dashboard
```

---

## API Endpoints

### POST `/api/register`
**Register new user and send verification email**

Request:
```json
{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "SecurePass123!"
}
```

Response (201 Created):
```json
{
  "message": "User created successfully. Please verify your email to activate your account.",
  "user": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "username": "john_doe",
    "email": "john@example.com",
    "is_verified": false,
    "created_at": "2026-08-23T22:30:00"
  }
}
```

### POST `/api/verify-email`
**Verify email with token**

Request:
```json
{
  "token": "verification_token_from_email"
}
```

Response (200 OK):
```json
{
  "message": "Email verified successfully! You can now login.",
  "user": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "username": "john_doe",
    "email": "john@example.com",
    "is_verified": true,
    "created_at": "2026-08-23T22:30:00"
  }
}
```

### GET `/verify-email/<token>`
**Verification page (user clicks email link)**

Returns: HTML verification page that auto-submits the token

---

## Database Schema

### EmailVerificationToken Table

```sql
CREATE TABLE email_verification_tokens (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL (references users.id),
  token VARCHAR(255) NOT NULL UNIQUE,
  created_at DATETIME DEFAULT now(),
  expires_at DATETIME NOT NULL,
  used BOOLEAN DEFAULT FALSE,
  INDEX idx_user_id (user_id),
  INDEX idx_token (token)
);
```

### User Table (Modified)

```sql
ALTER TABLE users ADD COLUMN is_verified BOOLEAN DEFAULT FALSE;
```

---

## Testing

### Test Flow

1. **Start the app:**
   ```bash
   source .venv/bin/activate
   python3.13 app.py
   ```

2. **Register new account:**
   - Username: `testuser`
   - Email: `cst.staber@gmail.com` (or your test email)
   - Password: `TestPass123!`

3. **Check email inbox:**
   - Look for email from your configured sender
   - Subject: "Verify Your Email"
   - Click the link

4. **Verify email:**
   - Page will load and auto-verify
   - Redirect to login page
   - You can now login!

### Test Unverified Login

Try logging in before verifying email:
- Username: `testuser`
- Password: `TestPass123!`
- Expected error: "Please verify your email before logging in"

### Test Expired Token

1. Wait 24+ hours (or manually edit database)
2. Try clicking verification link
3. Expected error: "Verification token has expired"

---

## Troubleshooting

### Email Not Sending

**Check 1: Environment Variables**
```bash
grep EMAIL_PROVIDER .env
grep MAIL_SERVER .env
grep MAIL_USERNAME .env
```

**Check 2: Gmail App Password**
- Make sure you used the 16-character app password (not regular password)
- Spaces in the password are normal and should be included

**Check 3: Enable Less Secure Apps (Gmail)**
If still not working:
1. Go to https://myaccount.google.com/lesssecureapps
2. Enable "Allow less secure apps"

**Check 4: Verify Credentials**
```bash
source .venv/bin/activate
python3.13 << 'EOF'
import os
from email_service import email_service
print(f"Provider: {email_service.provider}")
print(f"From: {email_service.from_addr}")
print(f"Config: MAIL_SERVER={os.getenv('MAIL_SERVER')}")
EOF
```

### Token Not Working

1. Check token hasn't expired (24 hours)
2. Check token is unique in database:
   ```bash
   sqlite3 login.db "SELECT * FROM email_verification_tokens WHERE used=0;"
   ```
3. Check user's `is_verified` status:
   ```bash
   sqlite3 login.db "SELECT username, is_verified FROM users;"
   ```

### Email Link Not Working

1. Verify `APP_URL` in `.env` matches your URL
2. Check logs for email body:
   ```bash
   grep "verify_url" app.py
   ```
3. Test manually:
   ```
   http://localhost:5000/verify-email/YOUR_TOKEN_HERE
   ```

---

## Production Deployment

### On DigitalOcean / AWS:

1. **Set environment variables:**
   ```bash
   export EMAIL_PROVIDER=smtp
   export MAIL_SERVER=smtp.gmail.com
   export MAIL_PORT=587
   export MAIL_USE_TLS=True
   export MAIL_USERNAME=your-email@gmail.com
   export MAIL_PASSWORD=your-app-password
   export APP_URL=https://yourdomain.com
   ```

2. **Use Docker:**
   ```bash
   docker-compose up -d
   ```

3. **Verify emails are working:**
   - Register a test account
   - Check your email provider's dashboard for sent emails

---

## Security Considerations

✅ **Implemented:**
- Tokens expire after 24 hours
- Tokens are single-use (marked as `used=True` after verification)
- Tokens are randomly generated with `secrets.token_urlsafe()`
- No email verification required for admin operations

⚠️ **Additional Hardening (Optional):**
- Implement rate limiting on email verification (prevent abuse)
- Add email confirmation resend endpoint
- Log all verification attempts
- Implement email whitelist for testing

---

## Future Enhancements

1. **Resend Verification Email:**
   - Add `/api/resend-verification` endpoint
   - Rate-limited to prevent spam

2. **Email Confirmation on Password Change:**
   - Send confirmation email when user changes password
   - Verify new email if email was changed

3. **Email Preferences:**
   - Allow users to opt-in/out of emails
   - Manage notification preferences

4. **Admin Dashboard:**
   - View verification status of all users
   - Manually verify users
   - Resend verification emails

---

## Support

For issues or questions:
1. Check logs: `cat /var/log/app/app.log`
2. Verify `.env` configuration
3. Test email provider credentials
4. Check database schema with `sqlite3 login.db ".schema"`

