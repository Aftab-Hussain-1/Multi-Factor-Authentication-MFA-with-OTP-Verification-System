# type: ignore
"""
Unit Tests using Python's standard unittest library
"""
import unittest
import json
from datetime import datetime, timedelta
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from database import SessionLocal, Base, engine
from app.models import User, EmailVerificationToken, PasswordResetToken
from app.services.password_utils import password_manager
from app.services.two_factor_service import two_factor_service
from app.services.user_service import user_service


class TestPasswordManager(unittest.TestCase):
    """Test password hashing and validation"""
    
    def test_hash_password(self):
        """Test password hashing"""
        password = "SecurePass123!"
        hashed = password_manager.hash_password(password)
        
        self.assertIsNotNone(hashed)
        self.assertTrue(hashed.startswith('$argon2id$'))
        self.assertNotEqual(hashed, password)
    
    def test_verify_password(self):
        """Test password verification"""
        password = "SecurePass123!"
        hashed = password_manager.hash_password(password)
        
        self.assertTrue(password_manager.verify_password(password, hashed))
        self.assertFalse(password_manager.verify_password("WrongPassword", hashed))
    
    def test_validate_password_strength(self):
        """Test password strength validation"""
        # Valid password
        valid, _ = password_manager.validate_password_strength("SecurePass123!")
        self.assertTrue(valid)
        
        # Too short
        valid, msg = password_manager.validate_password_strength("Short1!")
        self.assertFalse(valid)
        
        # No uppercase
        valid, msg = password_manager.validate_password_strength("nouppercase123!")
        self.assertFalse(valid)
        
        # No special character
        valid, msg = password_manager.validate_password_strength("NoSpecial123")
        self.assertFalse(valid)


class TestTwoFactorService(unittest.TestCase):
    """Test 2FA TOTP service"""
    
    def test_generate_secret(self):
        """Test TOTP secret generation"""
        secret = two_factor_service.generate_secret()
        
        self.assertIsNotNone(secret)
        self.assertGreater(len(secret), 0)
        self.assertIsInstance(secret, str)
    
    def test_generate_qr_code(self):
        """Test QR code generation"""
        secret = two_factor_service.generate_secret()
        qr_code = two_factor_service.generate_qr_code(secret, "test@example.com")
        
        self.assertIsNotNone(qr_code)
        self.assertTrue(qr_code.startswith('data:image/png;base64,'))
    
    def test_generate_backup_codes(self):
        """Test backup code generation"""
        codes = two_factor_service.generate_backup_codes(count=10)
        
        self.assertEqual(len(codes), 10)
        for code in codes:
            self.assertEqual(len(code), 8)
            self.assertTrue(code.isupper())


class TestUserService(unittest.TestCase):
    """Test user service validation"""
    
    def test_validate_username(self):
        """Test username validation"""
        # Valid usernames
        valid, msg = user_service.validate_username("valid_user123")
        self.assertTrue(valid)
        
        valid, msg = user_service.validate_username("john_doe")
        self.assertTrue(valid)
        
        # Invalid
        valid, msg = user_service.validate_username("ab")  # Too short
        self.assertFalse(valid)
        
        valid, msg = user_service.validate_username("a" * 50)  # Too long
        self.assertFalse(valid)
        
        valid, msg = user_service.validate_username("123user")  # Starts with number
        self.assertFalse(valid)
        
        valid, msg = user_service.validate_username("user@name")  # Invalid chars
        self.assertFalse(valid)
    
    def test_validate_email(self):
        """Test email validation"""
        # Valid emails
        valid, msg = user_service.validate_email("test@example.com")
        self.assertTrue(valid)
        
        valid, msg = user_service.validate_email("user+tag@domain.co.uk")
        self.assertTrue(valid)
        
        # Invalid emails
        valid, msg = user_service.validate_email("not-an-email")
        self.assertFalse(valid)
        
        valid, msg = user_service.validate_email("@example.com")
        self.assertFalse(valid)
        
        valid, msg = user_service.validate_email("user@")
        self.assertFalse(valid)


class TestAuthentication(unittest.TestCase):
    """Test authentication flows"""
    
    def setUp(self):
        """Set up test client and database"""
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()
        
        # Create tables
        with self.app.app_context():
            Base.metadata.create_all(engine)
    
    def tearDown(self):
        """Clean up database"""
        with self.app.app_context():
            Base.metadata.drop_all(engine)
    
    def test_register_user(self):
        """Test user registration"""
        response = self.client.post('/api/register', json={
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password': 'SecurePass123!'
        })
        
        self.assertEqual(response.status_code, 201)
        data = json.loads(response.data)
        self.assertIn('user', data)
        self.assertEqual(data['user']['username'], 'newuser')
        self.assertFalse(data['user']['is_verified'])
    
    def test_register_duplicate_username(self):
        """Test registration with duplicate username"""
        # Register first user
        self.client.post('/api/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'SecurePass123!'
        })
        
        # Try to register with same username
        response = self.client.post('/api/register', json={
            'username': 'testuser',
            'email': 'other@example.com',
            'password': 'SecurePass123!'
        })
        
        self.assertEqual(response.status_code, 400)
    
    def test_register_weak_password(self):
        """Test registration with weak password"""
        response = self.client.post('/api/register', json={
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password': 'weak'
        })
        
        self.assertEqual(response.status_code, 400)
    
    def test_login_requires_verified_email(self):
        """Test that login requires verified email"""
        # Register user
        self.client.post('/api/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'SecurePass123!'
        })
        
        # Try to login without verification
        response = self.client.post('/api/login', json={
            'username': 'testuser',
            'password': 'SecurePass123!'
        })
        
        self.assertEqual(response.status_code, 403)
        data = json.loads(response.data)
        self.assertIn('verify', data['error'].lower())
    
    def test_logout(self):
        """Test logout functionality"""
        response = self.client.post('/api/logout')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('successfully', data['message'].lower())


class TestSecurityFeatures(unittest.TestCase):
    """Test security features"""
    
    def setUp(self):
        """Set up test client"""
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()
        
        with self.app.app_context():
            Base.metadata.create_all(engine)
    
    def tearDown(self):
        """Clean up"""
        with self.app.app_context():
            Base.metadata.drop_all(engine)
    
    def test_protected_route_requires_login(self):
        """Test that protected routes require login"""
        response = self.client.get('/api/user-info')
        self.assertEqual(response.status_code, 401)
    
    def test_missing_fields_validation(self):
        """Test that API validates required fields"""
        response = self.client.post('/api/register', json={
            'username': 'testuser'
            # Missing email and password
        })
        
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)


if __name__ == '__main__':
    unittest.main(verbosity=2)
