#!/usr/bin/env python3
# Generate secure secrets for production deployment

import secrets
import argon2
import hashlib
import sys


def generate_secret_key(length: int = 32) -> str:
    # Generate cryptographically secure random key
    return secrets.token_hex(length)


def generate_password_hash() -> str:
    # Generate hash for default admin password
    password = "ChangeMe123!"
    hasher = argon2.PasswordHasher(
        time_cost=2,
        memory_cost=65536,
        parallelism=1,
        hash_len=32,
        salt_len=16
    )
    return hasher.hash(password)


def main():
    print("=" * 70)
    print("PRODUCTION SECRETS GENERATOR")
    print("=" * 70)
    print()
    
    # Generate SECRET_KEY for Flask
    print("[1] Flask SECRET_KEY (for session encryption)")
    secret_key = generate_secret_key(32)
    print(f"    SECRET_KEY={secret_key}")
    print()
    
    # Generate database password
    print("[2] Database Password (PostgreSQL)")
    db_password = generate_secret_key(16)
    print(f"    DB_PASSWORD={db_password}")
    print()
    
    # Generate Redis password
    print("[3] Redis Password (if using authenticated Redis)")
    redis_password = generate_secret_key(16)
    print(f"    REDIS_PASSWORD={redis_password}")
    print()
    
    # Generate JWT secret (for future use)
    print("[4] JWT Secret (for token-based auth)")
    jwt_secret = generate_secret_key(32)
    print(f"    JWT_SECRET={jwt_secret}")
    print()
    
    print("=" * 70)
    print("RECOMMENDED .env SECTION")
    print("=" * 70)
    print()
    print(f"SECRET_KEY={secret_key}")
    print(f"DATABASE_URL=postgresql://user:{db_password}@db:5432/login_db")
    print(f"REDIS_URL=redis://:{redis_password}@redis:6379/0")
    print(f"JWT_SECRET={jwt_secret}")
    print()
    
    print("=" * 70)
    print("SECURITY CHECKLIST")
    print("=" * 70)
    print("☐ Copy secrets above to .env file")
    print("☐ Commit .env to password manager (not Git)")
    print("☐ Store database password in secrets manager (AWS Secrets Manager, etc)")
    print("☐ Generate SSL certificates (Let's Encrypt): certbot certonly --standalone")
    print("☐ Configure MAIL_* variables for email service")
    print("☐ Set FLASK_ENV=production")
    print("☐ Disable DEBUG=False")
    print("☐ Enable SESSION_COOKIE_SECURE=True (HTTPS only)")
    print()


if __name__ == "__main__":
    main()
