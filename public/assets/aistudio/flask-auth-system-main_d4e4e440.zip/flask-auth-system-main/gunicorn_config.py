# Gunicorn configuration for production
import os
import multiprocessing

# Server Socket
bind = "0.0.0.0:5000"
backlog = 2048

# Worker Processes
workers = max(multiprocessing.cpu_count() * 2 + 1, 4)
worker_class = "sync"
worker_connections = 1000
timeout = 30
keepalive = 2

# Logging
accesslog = "/var/log/app/access.log"
errorlog = "/var/log/app/error.log"
loglevel = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# Process Naming
proc_name = "login-app"

# Server Mechanics
daemon = False
pidfile = "/var/run/gunicorn.pid"
umask = 0
user = "appuser"
group = "appuser"
tmp_upload_dir = None

# SSL
keyfile = os.getenv("SSL_KEY_FILE")
certfile = os.getenv("SSL_CERT_FILE")
ssl_version = "TLSv1_2"
cert_reqs = 2
ca_certs = None
ciphers = "TLSv1.2:!aNULL:!eNULL"

# Application
pythonpath = None
wsgi_app = "app:app"
raw_env = [
    f"DATABASE_URL={os.getenv('DATABASE_URL')}",
    f"REDIS_URL={os.getenv('REDIS_URL')}",
    f"FLASK_ENV={os.getenv('FLASK_ENV', 'production')}",
]

# Server Hooks
def when_ready(server):
    print("Gunicorn server is ready. Spawning workers")

def on_exit(server):
    print("Gunicorn server is shutting down")
