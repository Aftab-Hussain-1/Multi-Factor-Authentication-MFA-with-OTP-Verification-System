# Production Deployment Guide

## Overview
This guide covers deploying the authentication system to production using Docker, with support for AWS, DigitalOcean, or self-hosted servers.

## Prerequisites
- Docker and Docker Compose installed
- PostgreSQL 16+ running
- Redis 7+ running
- SMTP credentials or SendGrid API key for email
- SSL certificate (Let's Encrypt recommended)
- Domain name

## Deployment Options

### Option 1: DigitalOcean App Platform (Easiest)

#### Step 1: Prepare Code
```bash
git push origin main  # Push code to GitHub
```

#### Step 2: Create App on DigitalOcean
1. Go to [DigitalOcean App Platform](https://cloud.digitalocean.com/apps)
2. Connect GitHub repository
3. Select "login-python" repository
4. Choose deployment branch (main)

#### Step 3: Configure Components
1. **App Service**
   - Source: GitHub
   - Build command: `pip install -r requirements.txt`
   - Run command: `gunicorn --config gunicorn_config.py app:app`
   - HTTP port: 5000

2. **PostgreSQL Database**
   - Version: 16
   - Size: Basic ($15/mo for starter)

3. **Redis Cache**
   - Version: 7
   - Size: Basic

#### Step 4: Environment Variables
Set these in DigitalOcean environment:
```
DATABASE_URL=postgresql://user:password@db.ondigitalocean.com:25060/login_db?sslmode=require
REDIS_URL=redis://redis.ondigitalocean.com:25061
FLASK_ENV=production
SECRET_KEY=[generate strong key]
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=true
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=[app password]
MAIL_FROM_ADDR=noreply@yourapp.com
```

#### Step 5: Deploy
- Click "Deploy" button
- Wait for deployment to complete (~5 minutes)
- Access at your_app.ondigitalocean.app

---

### Option 2: AWS EC2 + RDS + ElastiCache (Scalable)

#### Step 1: Create VPC and Security Groups
```bash
# VPC security group for EC2
aws ec2 create-security-group \
  --group-name login-app-sg \
  --description "Login app security group" \
  --vpc-id vpc-xxxxx

# Allow HTTP/HTTPS/SSH
aws ec2 authorize-security-group-ingress \
  --group-id sg-xxxxx \
  --protocol tcp --port 22 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress \
  --group-id sg-xxxxx \
  --protocol tcp --port 80 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress \
  --group-id sg-xxxxx \
  --protocol tcp --port 443 --cidr 0.0.0.0/0

# Database security group
aws ec2 create-security-group \
  --group-name login-db-sg \
  --description "Login database security group" \
  --vpc-id vpc-xxxxx

# Allow PostgreSQL from app security group
aws ec2 authorize-security-group-ingress \
  --group-id sg-db-xxxxx \
  --protocol tcp --port 5432 \
  --source-security-group-id sg-xxxxx
```

#### Step 2: Create RDS PostgreSQL
```bash
aws rds create-db-instance \
  --db-instance-identifier login-db \
  --db-instance-class db.t3.micro \
  --engine postgres \
  --engine-version 16.1 \
  --master-username postgres \
  --master-user-password [strong-password] \
  --allocated-storage 20 \
  --vpc-security-group-ids sg-db-xxxxx \
  --db-subnet-group-name default \
  --multi-az \
  --storage-encrypted \
  --backup-retention-period 30
```

#### Step 3: Create ElastiCache Redis
```bash
aws elasticache create-cache-cluster \
  --cache-cluster-id login-redis \
  --cache-node-type cache.t3.micro \
  --engine redis \
  --engine-version 7.0 \
  --num-cache-nodes 1 \
  --security-group-ids sg-redis-xxxxx \
  --auto-minor-version-upgrade
```

#### Step 4: Launch EC2 Instance
```bash
aws ec2 run-instances \
  --image-id ami-0c55b159cbfafe1f0 \
  --instance-type t3.small \
  --key-name your-key \
  --security-group-ids sg-xxxxx \
  --subnet-id subnet-xxxxx \
  --user-data file://init-script.sh
```

#### Step 5: init-script.sh
```bash
#!/bin/bash
set -e

# Update system
apt-get update
apt-get upgrade -y

# Install Docker and Docker Compose
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
usermod -aG docker ubuntu

# Install Docker Compose
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# Clone repository
cd /home/ubuntu
git clone https://github.com/your-username/login-python.git
cd login-python

# Create .env file
cat > .env << EOF
DATABASE_URL=postgresql://postgres:password@login-db.xxxxx.rds.amazonaws.com:5432/login_db
REDIS_URL=redis://login-redis.xxxxx.cache.amazonaws.com:6379/0
FLASK_ENV=production
SECRET_KEY=$(openssl rand -hex 32)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=true
MAIL_USERNAME=$MAIL_USER
MAIL_PASSWORD=$MAIL_PASSWORD
MAIL_FROM_ADDR=noreply@yourapp.com
EOF

# Start application
docker-compose up -d
```

#### Step 6: Setup Nginx with SSL
```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-nginx

# Generate certificate
sudo certbot certonly --standalone -d yourdomain.com -d www.yourdomain.com

# Configure Nginx
sudo cp nginx.conf /etc/nginx/nginx.conf
sudo systemctl restart nginx
```

---

### Option 3: Self-Hosted Server (Full Control)

#### Step 1: SSH into Server
```bash
ssh -i your-key.pem ubuntu@your-server-ip
```

#### Step 2: Setup Server
```bash
# Update system
sudo apt-get update && sudo apt-get upgrade -y

# Install Docker and Docker Compose
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Clone repository
git clone https://github.com/your-username/login-python.git
cd login-python
```

#### Step 3: Create Environment File
```bash
cat > .env << 'EOF'
DATABASE_URL=postgresql://user:password@db:5432/login_db
REDIS_URL=redis://redis:6379/0
FLASK_ENV=production
SECRET_KEY=$(openssl rand -hex 32)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=true
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
MAIL_FROM_ADDR=noreply@yourapp.com
EOF
```

#### Step 4: Setup SSL Certificates
```bash
# Using Let's Encrypt
sudo apt-get install certbot

# Standalone mode for initial certificate
sudo certbot certonly --standalone -d yourdomain.com -d www.yourdomain.com

# Certificates will be at:
# /etc/letsencrypt/live/yourdomain.com/fullchain.pem
# /etc/letsencrypt/live/yourdomain.com/privkey.pem

# Create certificate directory in project
mkdir -p certs
sudo cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem certs/cert.pem
sudo cp /etc/letsencrypt/live/yourdomain.com/privkey.pem certs/key.pem
sudo chown $USER:$USER certs/*
```

#### Step 5: Start Services
```bash
# Create necessary directories
mkdir -p logs
mkdir -p postgres_data
mkdir -p redis_data

# Start Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f app
```

#### Step 6: Setup Auto-renewal for SSL
```bash
# Create renewal script
sudo tee /etc/cron.d/certbot-renewal << EOF
0 3 * * * root certbot renew --quiet && cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem /path/to/project/certs/cert.pem && cp /etc/letsencrypt/live/yourdomain.com/privkey.pem /path/to/project/certs/key.pem && docker-compose -f /path/to/project/docker-compose.yml restart nginx
EOF
```

---

## Post-Deployment Tasks

### 1. Database Initialization
```bash
docker-compose exec app python -c "from database import init_db; init_db()"
```

### 2. Create Admin User
```bash
docker-compose exec app python << 'EOF'
from database import SessionLocal
from user_service import user_service

db = SessionLocal()
user, error = user_service.create_user(db, 'admin', 'admin@example.com', 'SecurePassword123!')
if error:
    print(f"Error: {error}")
else:
    print(f"Admin user created: {user.username}")
db.close()
EOF
```

### 3. Monitor Application
```bash
# View real-time logs
docker-compose logs -f app

# View container status
docker-compose ps

# Check resource usage
docker stats
```

### 4. Setup Monitoring & Alerts
```bash
# View Gunicorn access logs
docker-compose exec app tail -f /var/log/app/access.log

# Setup log aggregation (Optional: ELK stack, CloudWatch)
```

### 5. Backup Database
```bash
# Manual backup
docker-compose exec db pg_dump -U user login_db > backup.sql

# Automated daily backups (cron)
0 2 * * * docker-compose -f /path/to/docker-compose.yml exec -T db pg_dump -U user login_db > /backups/db_$(date +\%Y\%m\%d).sql
```

## Security Checklist

- [x] Environment variables configured (not in code)
- [x] SSL/TLS enabled for HTTPS
- [x] Rate limiting configured
- [x] CORS restricted to frontend domains
- [x] Password hashing with Argon2
- [x] Database user has minimal privileges
- [x] Gunicorn worker count optimized
- [x] Security headers configured in Nginx
- [x] Database backups automated
- [x] Logs collected and monitored
- [x] Failed login attempts logged
- [x] 2FA enabled for admin accounts
- [x] Regular security updates enabled
- [ ] WAF rules configured (optional)
- [ ] DDoS protection enabled (CloudFlare recommended)

## Scaling Recommendations

1. **Database:**
   - Use read replicas for read-heavy workloads
   - Enable automatic failover
   - Increase backup frequency

2. **Redis:**
   - Use cluster mode for high availability
   - Configure persistence (AOF recommended)

3. **Application:**
   - Increase Gunicorn workers (4-8 per core)
   - Use load balancer (ALB/NLB)
   - Auto-scaling group based on CPU

4. **Storage:**
   - Use S3 or object storage for files
   - CDN for static assets (CloudFront/Cloudflare)

## Troubleshooting

### Database Connection Error
```bash
# Check RDS/DB connectivity
docker-compose exec app python -c "from database import engine; print(engine.execute('SELECT 1'))"

# Verify DATABASE_URL format
docker-compose exec app echo $DATABASE_URL
```

### Redis Connection Error
```bash
# Test Redis connection
docker-compose exec redis redis-cli ping

# Check REDIS_URL in environment
docker-compose exec app echo $REDIS_URL
```

### SSL Certificate Issues
```bash
# Verify certificate
openssl x509 -in certs/cert.pem -text -noout

# Renew certificate
sudo certbot renew --force-renewal
```

### High Memory Usage
```bash
# Check container memory
docker stats

# Reduce Gunicorn workers
# Edit gunicorn_config.py and restart
docker-compose restart app
```

## Support
For issues, check logs:
```bash
docker-compose logs app  # Application logs
docker-compose logs db   # Database logs
docker-compose logs nginx # Web server logs
```
