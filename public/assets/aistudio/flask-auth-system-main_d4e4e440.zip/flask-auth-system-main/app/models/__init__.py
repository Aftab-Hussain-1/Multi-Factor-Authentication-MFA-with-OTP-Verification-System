"""Database models for user authentication system"""
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Boolean, Index
from sqlalchemy.dialects.postgresql import UUID
import uuid
from database import Base


class User(Base):  # type: ignore
    # User entity with secure password storage
    __tablename__ = 'users'

    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        nullable=False
    )

    username = Column(String(255), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_verified = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    last_login = Column(DateTime, nullable=True)
    
    __table_args__ = (
        Index('idx_username', 'username'),
        Index('idx_email', 'email'),
        Index('idx_is_active', 'is_active'),
    )

    def __repr__(self):
        return f'<User(id={self.id}, username={self.username}, email={self.email})>'

    def to_dict(self, include_sensitive=False):
        # Convert user to dict (excludes password hash by default)
        data = {
            'id': str(self.id),
            'username': self.username,
            'email': self.email,
            'is_active': self.is_active,
            'is_verified': self.is_verified,
            'created_at': self.created_at.isoformat() if self.created_at else None,  # type: ignore
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,  # type: ignore
            'last_login': self.last_login.isoformat() if self.last_login else None,  # type: ignore
        }
        if include_sensitive:
            data['password_hash'] = self.password_hash
        return data


class PasswordResetToken(Base):  # type: ignore
    # Password reset token for forgot password flow
    __tablename__ = 'password_reset_tokens'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, nullable=False)
    user_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    token = Column(String(255), unique=True, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    used = Column(Boolean, default=False, nullable=False)

    def __repr__(self):
        return f'<PasswordResetToken(user_id={self.user_id}, token={self.token[:10]}...)>'


class TwoFactorToken(Base):  # type: ignore
    # 2FA TOTP secret for each user
    __tablename__ = 'two_factor_tokens'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, nullable=False)
    user_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    secret = Column(String(32), nullable=False)
    is_enabled = Column(Boolean, default=False, nullable=False)
    backup_codes = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    def __repr__(self):
        return f'<TwoFactorToken(user_id={self.user_id}, enabled={self.is_enabled})>'


class EmailVerificationToken(Base):  # type: ignore
    # Email verification token for new user registration
    __tablename__ = 'email_verification_tokens'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, nullable=False)
    user_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    token = Column(String(255), unique=True, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    used = Column(Boolean, default=False, nullable=False)

    def __repr__(self):
        return f'<EmailVerificationToken(user_id={self.user_id}, token={self.token[:10]}...)>'


class LoginAttempt(Base):  # type: ignore
    # Track login attempts for rate limiting and security
    __tablename__ = 'login_attempts'

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, nullable=False)
    username = Column(String(255), nullable=False, index=True)
    ip_address = Column(String(45), nullable=False, index=True)
    success = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

    def __repr__(self):
        return f'<LoginAttempt(username={self.username}, success={self.success}, created_at={self.created_at})>'
