# type: ignore
"""Admin dashboard setup for user management"""
from flask_admin import Admin, AdminIndexView
from flask_admin.contrib.sqla import ModelView
from flask import redirect, url_for, session
from database import SessionLocal
from app.models import User, PasswordResetToken, TwoFactorToken, LoginAttempt


class AdminIndexView(AdminIndexView):
    # Custom admin index page with authentication
    
    def is_accessible(self):
        # Check if user is admin
        return 'user_id' in session and session.get('is_admin', False)
    
    def inaccessible_callback(self, name, **kwargs):
        # Redirect to login if not admin
        return redirect(url_for('auth.index'))


class UserAdmin(ModelView):
    # User management in admin panel
    
    column_list = ('id', 'username', 'email', 'is_active', 'is_verified', 'created_at', 'last_login')
    column_filters = ['username', 'email', 'is_active', 'created_at']
    column_searchable_list = ['username', 'email']
    form_excluded_columns = ['password_hash']
    can_delete = True
    can_edit = True
    can_view_details = True
    
    def is_accessible(self):
        return 'user_id' in session and session.get('is_admin', False)
    
    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('auth.index'))


class LoginAttemptAdmin(ModelView):
    # Login attempt monitoring
    
    column_list = ('username', 'ip_address', 'success', 'created_at')
    column_filters = ['username', 'ip_address', 'success', 'created_at']
    column_searchable_list = ['username', 'ip_address']
    can_delete = False
    can_edit = False
    can_create = False
    
    def is_accessible(self):
        return 'user_id' in session and session.get('is_admin', False)
    
    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('auth.index'))


class PasswordResetTokenAdmin(ModelView):
    # Password reset token monitoring
    
    column_list = ('user_id', 'created_at', 'expires_at', 'used')
    column_filters = ['used', 'created_at']
    can_delete = True
    can_edit = False
    can_create = False
    
    def is_accessible(self):
        return 'user_id' in session and session.get('is_admin', False)
    
    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('auth.index'))


def setup_admin(app):
    """Setup Flask-Admin with all models"""
    admin = Admin(
        app,
        name='Login Admin',
        index_view=AdminIndexView(),
        template_mode='bootstrap4'
    )
    
    db = SessionLocal()
    try:
        admin.add_view(UserAdmin(User, db, endpoint='admin_user'))
        admin.add_view(LoginAttemptAdmin(LoginAttempt, db, endpoint='admin_login_attempt'))
        admin.add_view(PasswordResetTokenAdmin(PasswordResetToken, db, endpoint='admin_password_reset'))
    finally:
        pass  # Keep session open for admin
