"""Flask application factory and setup"""
from flask import Flask
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_cors import CORS
from datetime import timedelta
import os

from database import init_db, engine, Base
from app.admin import setup_admin


def create_app():
    """Application factory pattern"""
    app = Flask(__name__, 
                template_folder='../templates',
                static_folder='../static')
    
    # Configuration
    app.secret_key = os.getenv('SECRET_KEY', 'change-this-key-in-production')
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SECURE'] = os.getenv('FLASK_ENV') == 'production'
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)
    
    # Rate limiting
    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        default_limits=["200 per day", "50 per hour"],
        storage_uri=os.getenv('REDIS_URL', 'memory://')
    )
    app.limiter = limiter  # type: ignore
    
    # CORS support
    CORS(app, supports_credentials=True)
    
    # Initialize database
    Base.metadata.create_all(engine)
    
    # Setup Flask-Admin
    setup_admin(app)
    
    # Register blueprints
    from app.routes.auth import auth_bp
    from app.routes.twofa import twofa_bp
    from app.routes.user import user_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(twofa_bp)
    app.register_blueprint(user_bp)
    
    return app
