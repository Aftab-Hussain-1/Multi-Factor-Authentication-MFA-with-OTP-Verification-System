# type: ignore
# Two-Factor Authentication service with TOTP
import pyotp
import qrcode
from io import BytesIO
import base64


class TwoFactorService:
    # TOTP-based 2FA management
    
    @staticmethod
    def generate_secret() -> str:
        # Generate new TOTP secret
        return pyotp.random_base32()
    
    @staticmethod
    def get_totp_uri(secret: str, username: str, issuer: str = "YourApp") -> str:
        # Get TOTP provisioning URI
        totp = pyotp.TOTP(secret)
        return totp.provisioning_uri(name=username, issuer_name=issuer)
    
    @staticmethod
    def generate_qr_code(secret: str, username: str, issuer: str = "YourApp") -> str:
        # Generate QR code as base64 image
        uri = TwoFactorService.get_totp_uri(secret, username, issuer)
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(uri)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode()
        
        return f"data:image/png;base64,{img_str}"
    
    @staticmethod
    def verify_token(secret: str, token: str, window: int = 1) -> bool:
        # Verify TOTP token (with time window tolerance)
        totp = pyotp.TOTP(secret)
        return totp.verify(token, valid_window=window)
    
    @staticmethod
    def generate_backup_codes(count: int = 10) -> list[str]:
        # Generate backup codes for account recovery
        codes = []
        for _ in range(count):
            code = pyotp.random_base32()[:8].upper()
            codes.append(code)
        return codes


two_factor_service = TwoFactorService()
