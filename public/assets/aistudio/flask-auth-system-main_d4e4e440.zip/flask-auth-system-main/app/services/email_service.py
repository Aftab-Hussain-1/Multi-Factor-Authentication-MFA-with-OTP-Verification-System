# type: ignore
# Email service for sending password reset, 2FA, notifications
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from database import SessionLocal
from app.models import User, PasswordResetToken, TwoFactorToken


class EmailService:
    # Email sender using SMTP or SendGrid
    
    def __init__(self):
        self.provider = os.getenv('EMAIL_PROVIDER', 'smtp').lower()
        self.from_addr = os.getenv('MAIL_FROM_ADDR', 'noreply@app.com')
        self.from_name = os.getenv('MAIL_FROM_NAME', 'App')
    
    def send_email(self, to_email: str, subject: str, html_body: str, text_body: str = None) -> bool:
        # Send email via configured provider
        try:
            if self.provider == 'smtp':
                return self._send_smtp(to_email, subject, html_body, text_body)
            elif self.provider == 'sendgrid':
                return self._send_sendgrid(to_email, subject, html_body)
            else:
                print(f"Unknown email provider: {self.provider}")
                return False
        except Exception as e:
            print(f"Email send error: {e}")
            return False
    
    def _send_smtp(self, to_email: str, subject: str, html_body: str, text_body: str = None) -> bool:
        # Send via SMTP (Gmail, Outlook, etc.)
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = f"{self.from_name} <{self.from_addr}>"
        msg['To'] = to_email
        
        if text_body:
            msg.attach(MIMEText(text_body, 'plain'))
        msg.attach(MIMEText(html_body, 'html'))
        
        try:
            server = smtplib.SMTP(os.getenv('MAIL_SERVER'), int(os.getenv('MAIL_PORT', 587)))
            if os.getenv('MAIL_USE_TLS', 'True').lower() == 'true':
                server.starttls()
            server.login(os.getenv('MAIL_USERNAME'), os.getenv('MAIL_PASSWORD'))
            server.send_message(msg)
            server.quit()
            return True
        except Exception as e:
            print(f"SMTP error: {e}")
            return False
    
    def _send_sendgrid(self, to_email: str, subject: str, html_body: str) -> bool:
        # Send via SendGrid
        try:
            import sendgrid
            from sendgrid.helpers.mail import Mail
            
            message = Mail(
                from_email=self.from_addr,
                to_emails=to_email,
                subject=subject,
                html_content=html_body
            )
            sg = sendgrid.SendGridAPIClient(os.getenv('SENDGRID_API_KEY'))
            sg.send(message)
            return True
        except Exception as e:
            print(f"SendGrid error: {e}")
            return False
    
    def send_verification_email(self, user: User, verification_token: str) -> bool:
        # Send email verification link
        verify_url = f"{os.getenv('APP_URL', 'http://localhost:5001')}/verify-email/{verification_token}"
        
        html_body = f"""
        <html>
            <body>
                <h2>Verify Your Email</h2>
                <p>Hi {user.username},</p>
                <p>Welcome to our app! Please verify your email to activate your account:</p>
                <a href="{verify_url}">Verify Email</a>
                <p>This link expires in 24 hours.</p>
                <p>If you didn't create this account, you can ignore this email.</p>
            </body>
        </html>
        """
        
        text_body = f"Click here to verify your email: {verify_url}\nThis link expires in 24 hours."
        return self.send_email(user.email, "Verify Your Email", html_body, text_body)
    
    def send_password_reset_email(self, user: User, reset_token: str) -> bool:
        # Send password reset email
        reset_url = f"{os.getenv('APP_URL', 'http://localhost:5001')}/reset-password/{reset_token}"
        
        html_body = f"""
        <html>
            <body>
                <h2>Password Reset Request</h2>
                <p>Hi {user.username},</p>
                <p>We received a request to reset your password. Click the link below to reset it:</p>
                <a href="{reset_url}">Reset Password</a>
                <p>This link expires in 1 hour.</p>
                <p>If you didn't request this, ignore this email.</p>
            </body>
        </html>
        """
        
        text_body = f"Click here to reset your password: {reset_url}\nThis link expires in 1 hour."
        return self.send_email(user.email, "Password Reset Request", html_body, text_body)
    
    def send_2fa_email(self, user: User, code: str) -> bool:
        # Send 2FA code email
        html_body = f"""
        <html>
            <body>
                <h2>Two-Factor Authentication Code</h2>
                <p>Hi {user.username},</p>
                <p>Your 2FA code is: <strong>{code}</strong></p>
                <p>This code expires in 5 minutes.</p>
                <p>If you didn't request this, please secure your account immediately.</p>
            </body>
        </html>
        """
        
        text_body = f"Your 2FA code is: {code}\nThis code expires in 5 minutes."
        return self.send_email(user.email, "Two-Factor Authentication Code", html_body, text_body)
    
    def send_welcome_email(self, user: User) -> bool:
        # Send welcome email
        html_body = f"""
        <html>
            <body>
                <h2>Welcome to Our App!</h2>
                <p>Hi {user.username},</p>
                <p>Your account has been successfully created.</p>
                <p>You can now login with your credentials.</p>
            </body>
        </html>
        """
        
        text_body = "Welcome to our app! You can now login with your credentials."
        return self.send_email(user.email, "Welcome to Our App", html_body, text_body)


email_service = EmailService()
