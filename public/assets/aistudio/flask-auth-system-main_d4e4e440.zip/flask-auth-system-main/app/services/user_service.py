# type: ignore
# User management service
from datetime import datetime
from uuid import UUID
from email_validator import validate_email, EmailNotValidError
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.models import User
from app.services.password_utils import password_manager


class UserService:
    # Manage users and authentication
    
    @staticmethod
    def validate_username(username: str) -> tuple[bool, str]:
        # Validate username format (3-32 chars, alphanumeric + underscore)
        if not isinstance(username, str):
            return False, 'Username must be a string'
        
        if len(username) < 3 or len(username) > 32:
            return False, 'Username must be between 3 and 32 characters'
        
        if not username[0].isalpha():
            return False, 'Username must start with a letter'
        
        if not all(c.isalnum() or c == '_' for c in username):
            return False, 'Username can only contain letters, numbers, and underscores'
        
        return True, ''
    
    @staticmethod
    def validate_email(email: str) -> tuple[bool, str]:
        # Validate email format
        try:
            validate_email(email, check_deliverability=False)
            return True, ''
        except EmailNotValidError as e:
            return False, str(e)
    
    @staticmethod
    def create_user(
        db: Session,
        username: str,
        email: str,
        password: str
    ) -> tuple[User | None, str]:
        # Create new user with hashed password
        is_valid, error = UserService.validate_username(username)
        if not is_valid:
            return None, f'Invalid username: {error}'
        
        is_valid, error = UserService.validate_email(email)
        if not is_valid:
            return None, f'Invalid email: {error}'
        
        try:
            password_hash = password_manager.hash_password(password)
        except ValueError as e:
            return None, str(e)
        
        user = User(
            username=username,
            email=email,
            password_hash=password_hash
        )
        
        try:
            db.add(user)
            db.commit()
            db.refresh(user)
            return user, ''
        except IntegrityError as e:
            db.rollback()
            if 'username' in str(e):
                return None, f'Username "{username}" already exists'
            elif 'email' in str(e):
                return None, f'Email "{email}" already exists'
            else:
                return None, 'Database error: duplicate entry'
        except Exception as e:
            db.rollback()
            return None, f'Error creating user: {str(e)}'
    
    @staticmethod
    def authenticate_user(
        db: Session,
        username: str,
        password: str
    ) -> tuple[User | None, str]:
        # Authenticate user and update last login
        user = db.query(User).filter(User.username == username).first()
        
        if not user:
            return None, 'Invalid username or password'
        
        if not user.is_active:
            return None, 'User account is deactivated'
        
        if not password_manager.verify_password(password, user.password_hash):
            return None, 'Invalid username or password'
        
        user.last_login = datetime.utcnow()
        db.commit()
        
        return user, ''
    
    @staticmethod
    def get_user_by_id(db: Session, user_id: str) -> User | None:
        # Get user by ID (convert string to UUID)
        if isinstance(user_id, str):
            user_id = UUID(user_id)
        return db.query(User).filter(User.id == user_id).first()
    
    @staticmethod
    def get_user_by_username(db: Session, username: str) -> User | None:
        # Get user by username
        return db.query(User).filter(User.username == username).first()
    
    @staticmethod
    def get_user_by_email(db: Session, email: str) -> User | None:
        # Get user by email
        return db.query(User).filter(User.email == email).first()
    
    @staticmethod
    def change_password(
        db: Session,
        user: User,
        old_password: str,
        new_password: str
    ) -> tuple[bool, str]:
        # Change password with validation
        if not password_manager.verify_password(old_password, user.password_hash):
            return False, 'Current password is incorrect'
        
        try:
            new_hash = password_manager.hash_password(new_password)
        except ValueError as e:
            return False, str(e)
        
        if password_manager.verify_password(new_password, user.password_hash):
            return False, 'New password must be different from current password'
        
        user.password_hash = new_hash
        user.updated_at = datetime.utcnow()
        db.commit()
        
        return True, 'Password changed successfully'
    
    @staticmethod
    def deactivate_user(db: Session, user: User) -> bool:
        # Deactivate user account
        user.is_active = False
        user.updated_at = datetime.utcnow()
        db.commit()
        return True
    
    @staticmethod
    def reactivate_user(db: Session, user: User) -> bool:
        # Reactivate user account
        user.is_active = True
        user.updated_at = datetime.utcnow()
        db.commit()
        return True
    
    @staticmethod
    def _validate_password_strength(password: str) -> tuple[bool, str]:
        # Validate password strength
        try:
            password_manager.validate_password_strength(password)
            return True, ''
        except ValueError as e:
            return False, str(e)


user_service = UserService()
