# Argon2 password hashing and validation
import re
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHash
from config import Config


class PasswordManager:
    # Hash and verify passwords with Argon2
    
    def __init__(self):
        self.hasher = PasswordHasher(
            time_cost=Config.ARGON2_TIME_COST,
            memory_cost=Config.ARGON2_MEMORY_COST,
            parallelism=Config.ARGON2_PARALLELISM,
            hash_len=32,
            salt_len=16
        )
    
    @staticmethod
    def validate_password_strength(password: str) -> tuple[bool, str]:
        # Validate password against security policy
        errors = []
        if len(password) < Config.MIN_PASSWORD_LENGTH:
            errors.append(f'Password must be at least {Config.MIN_PASSWORD_LENGTH} characters long')
        if Config.REQUIRE_UPPERCASE and not re.search(r'[A-Z]', password):
            errors.append('Password must contain at least one uppercase letter')
        if Config.REQUIRE_LOWERCASE and not re.search(r'[a-z]', password):
            errors.append('Password must contain at least one lowercase letter')
        if Config.REQUIRE_DIGITS and not re.search(r'\d', password):
            errors.append('Password must contain at least one digit')
        if Config.REQUIRE_SPECIAL_CHARS and not re.search(r'[!@#$%^&*()_+\-=\[\]{};:\'",.<>?/\\|`~]', password):
            errors.append('Password must contain at least one special character')
        if errors:
            return False, ' | '.join(errors)
        return True, ''
    
    def hash_password(self, password: str) -> str:
        # Hash password with Argon2
        is_valid, error_msg = self.validate_password_strength(password)
        if not is_valid:
            raise ValueError(f'Weak password: {error_msg}')
        return self.hasher.hash(password)
    
    def verify_password(self, password: str, password_hash: str) -> bool:
        # Verify password against hash
        try:
            self.hasher.verify(password_hash, password)
            return True
        except (VerifyMismatchError, InvalidHash):
            return False
    
    def needs_rehash(self, password_hash: str) -> bool:
        # Check if hash needs rehashing with updated parameters
        try:
            return self.hasher.check_needs_rehash(password_hash)
        except InvalidHash:
            return True


password_manager = PasswordManager()
