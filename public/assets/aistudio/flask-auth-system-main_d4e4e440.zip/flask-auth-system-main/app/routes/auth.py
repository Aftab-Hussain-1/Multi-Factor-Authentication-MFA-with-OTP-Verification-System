# type: ignore
"""Authentication routes with OpenAPI/Swagger documentation"""
import os
import logging
import secrets
from functools import wraps
from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
from datetime import datetime, timedelta
from database import SessionLocal
from app.services.user_service import user_service
from app.services.email_service import email_service
from app.models import User, PasswordResetToken, EmailVerificationToken, LoginAttempt, TwoFactorToken
from app.services.password_utils import password_manager

auth_bp = Blueprint('auth', __name__)
logger = logging.getLogger(__name__)


def require_login(f):
    """Decorator to protect routes requiring authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Not authenticated'}), 401
        return f(*args, **kwargs)
    return decorated_function


def log_login_attempt(db, username: str, success: bool):
    """Log login attempt for security tracking"""
    try:
        ip_address = request.remote_addr or 'unknown'
        attempt = LoginAttempt(username=username, ip_address=ip_address, success=success)
        db.add(attempt)
        db.commit()
    except Exception as e:
        logger.error(f"Error logging login attempt: {e}")


@auth_bp.route('/')
def index():
    """Show login page if not authenticated"""
    if 'user_id' in session:
        return redirect(url_for('auth.dashboard'))
    return render_template('index.html')


@auth_bp.route('/dashboard')
@require_login
def dashboard():
    """User dashboard (requires authentication)"""
    db = SessionLocal()
    try:
        user = user_service.get_user_by_id(db, session['user_id'])
        return render_template('dashboard.html', user=user.to_dict() if user else None)
    finally:
        db.close()


@auth_bp.route('/verify-email/<token>')
def verify_email_page(token):
    """Verify email page (when user clicks link in email)"""
    return render_template('verify-email.html', token=token)


@auth_bp.route('/reset-password/<token>')
def reset_password_page(token):
    """Password reset page (when user clicks link in email)"""
    return render_template('reset-password.html')


@auth_bp.route('/api/register', methods=['POST'])
def api_register():
    """
    Register new user with email verification
    ---
    tags:
      - Authentication
    parameters:
      - name: body
        in: body
        required: true
        schema:
          type: object
          required:
            - username
            - email
            - password
          properties:
            username:
              type: string
              example: john_doe
              minLength: 3
              maxLength: 32
              description: "Username (3-32 chars, alphanumeric + underscore, starts with letter)"
            email:
              type: string
              example: john@example.com
              format: email
              description: "Valid email address"
            password:
              type: string
              example: SecurePass123!
              minLength: 8
              description: "Min 8 chars: uppercase, lowercase, number, special char (!@#$%^&*)"
    responses:
      201:
        description: User registered successfully. Email verification sent.
        schema:
          type: object
          properties:
            message:
              type: string
            user:
              type: object
              properties:
                id:
                  type: string
                username:
                  type: string
                email:
                  type: string
                is_verified:
                  type: boolean
      400:
        description: Validation error
        schema:
          type: object
          properties:
            error:
              type: string
      500:
        description: Server error
    """
    data = request.json or {}
    username = data.get('username', '').strip()
    email = data.get('email', '').strip()
    password = data.get('password', '')
    
    if not username or not email or not password:
        return jsonify({'error': 'All fields required'}), 400
    
    db = SessionLocal()
    try:
        user, error = user_service.create_user(db, username, email, password)
        if error:
            return jsonify({'error': error}), 400
        
        # User created but not verified - generate verification token
        verification_token = secrets.token_urlsafe(32)
        email_verification = EmailVerificationToken(
            user_id=user.id,
            token=verification_token,
            expires_at=datetime.utcnow() + timedelta(hours=24),
            used=False
        )
        db.add(email_verification)
        db.commit()
        
        # Send verification email
        email_service.send_verification_email(user, verification_token)
        
        logger.info(f"New user registered: {username} (awaiting email verification)")
        return jsonify({
            'message': 'User created successfully. Please verify your email to activate your account.',
            'user': user.to_dict()
        }), 201
    except Exception as e:
        logger.error(f"Registration error: {e}")
        return jsonify({'error': 'Registration failed'}), 500
    finally:
        db.close()


@auth_bp.route('/api/login', methods=['POST'])
def api_login():
    """
    Authenticate user and start session
    ---
    tags:
      - Authentication
    parameters:
      - name: body
        in: body
        required: true
        schema:
          type: object
          required:
            - username
            - password
          properties:
            username:
              type: string
              example: john_doe
            password:
              type: string
              example: SecurePass123!
    responses:
      200:
        description: Login successful or 2FA required
        schema:
          type: object
          properties:
            message:
              type: string
            user:
              type: object
            requires_2fa:
              type: boolean
      401:
        description: Invalid credentials
      403:
        description: Email not verified
      429:
        description: Too many login attempts (rate limited)
    """
    data = request.json or {}
    username = data.get('username', '').strip()
    password = data.get('password', '')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    db = SessionLocal()
    try:
        user, error = user_service.authenticate_user(db, username, password)
        log_login_attempt(db, username, error == '')
        
        if error:
            logger.warning(f"Failed login attempt: {username}")
            return jsonify({'error': error}), 401
        
        # Check if email is verified
        if not user.is_verified:
            logger.warning(f"Login attempt with unverified email: {username}")
            return jsonify({'error': 'Please verify your email before logging in'}), 403
        
        # Check if 2FA is enabled
        twofa = db.query(TwoFactorToken).filter(TwoFactorToken.user_id == user.id).first()
        if twofa and twofa.is_enabled:
            session['pre_auth_user_id'] = str(user.id)
            session['pre_auth_username'] = user.username
            return jsonify({'message': '2FA required', 'requires_2fa': True, 'user': user.to_dict()}), 200
        
        session.permanent = True
        session['user_id'] = str(user.id)
        session['username'] = user.username
        logger.info(f"User logged in: {username}")
        return jsonify({'message': 'Login successful', 'user': user.to_dict()}), 200
    except Exception as e:
        logger.error(f"Login error: {e}")
        return jsonify({'error': 'Login failed'}), 500
    finally:
        db.close()


@auth_bp.route('/api/verify-email', methods=['POST'])
def api_verify_email():
    """
    Verify email with token
    ---
    tags:
      - Authentication
    parameters:
      - name: body
        in: body
        required: true
        schema:
          type: object
          required:
            - token
          properties:
            token:
              type: string
              description: "Email verification token from email link"
    responses:
      200:
        description: Email verified successfully
        schema:
          type: object
          properties:
            message:
              type: string
            user:
              type: object
      400:
        description: Invalid or expired token
    """
    data = request.json or {}
    token = data.get('token', '').strip()
    
    if not token:
        return jsonify({'error': 'Verification token required'}), 400
    
    db = SessionLocal()
    try:
        # Find the verification token
        email_token = db.query(EmailVerificationToken).filter(
            EmailVerificationToken.token == token,
            EmailVerificationToken.used == False
        ).first()
        
        if not email_token:
            return jsonify({'error': 'Invalid or expired verification token'}), 400
        
        # Check if token is expired
        if datetime.utcnow() > email_token.expires_at:
            return jsonify({'error': 'Verification token has expired'}), 400
        
        # Get the user and mark as verified
        user = db.query(User).filter(User.id == email_token.user_id).first()
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Mark user as verified and token as used
        user.is_verified = True
        email_token.used = True
        db.commit()
        
        logger.info(f"Email verified for user: {user.username}")
        return jsonify({
            'message': 'Email verified successfully! You can now login.',
            'user': user.to_dict()
        }), 200
    except Exception as e:
        logger.error(f"Email verification error: {e}")
        return jsonify({'error': 'Email verification failed'}), 500
    finally:
        db.close()


@auth_bp.route('/api/logout', methods=['POST'])
def api_logout():
    """
    Logout and clear session
    ---
    tags:
      - Authentication
    responses:
      200:
        description: Logged out successfully
    """
    username = session.get('username', 'unknown')
    session.clear()
    logger.info(f"User logged out: {username}")
    return jsonify({'message': 'Logged out successfully'}), 200


@auth_bp.route('/api/forgot-password', methods=['POST'])
def api_forgot_password():
    """
    Request password reset link
    ---
    tags:
      - Password Reset
    parameters:
      - name: body
        in: body
        required: true
        schema:
          type: object
          required:
            - email
          properties:
            email:
              type: string
              example: john@example.com
              format: email
    responses:
      200:
        description: If email exists, reset link sent
        schema:
          type: object
          properties:
            message:
              type: string
      429:
        description: Too many password reset attempts
    """
    data = request.json or {}
    email = data.get('email', '').strip()
    
    if not email:
        return jsonify({'error': 'Email required'}), 400
    
    db = SessionLocal()
    try:
        user = user_service.get_user_by_email(db, email)
        if not user:
            return jsonify({'message': 'If email exists, reset link sent'}), 200
        
        # Generate reset token
        reset_token = secrets.token_urlsafe(32)
        expires_at = datetime.utcnow() + timedelta(hours=1)
        
        db_token = PasswordResetToken(user_id=user.id, token=reset_token, expires_at=expires_at)
        db.add(db_token)
        db.commit()
        
        # Send reset email
        email_service.send_password_reset_email(user, reset_token)
        logger.info(f"Password reset requested: {email}")
        return jsonify({'message': 'If email exists, reset link sent'}), 200
    except Exception as e:
        logger.error(f"Forgot password error: {e}")
        return jsonify({'error': 'Request failed'}), 500
    finally:
        db.close()


@auth_bp.route('/api/reset-password', methods=['POST'])
def api_reset_password():
    """
    Reset password using token
    ---
    tags:
      - Password Reset
    parameters:
      - name: body
        in: body
        required: true
        schema:
          type: object
          required:
            - token
            - password
          properties:
            token:
              type: string
              description: "Password reset token from email link"
            password:
              type: string
              example: NewSecurePass123!
              minLength: 8
              description: "New password (8+ chars, uppercase, lowercase, number, special)"
    responses:
      200:
        description: Password reset successfully
      400:
        description: Invalid token or password
      404:
        description: User not found
    """
    data = request.json or {}
    token = data.get('token', '').strip()
    new_password = data.get('password', '')
    
    if not token or not new_password:
        return jsonify({'error': 'Token and password required'}), 400
    
    db = SessionLocal()
    try:
        reset_token = db.query(PasswordResetToken).filter(
            PasswordResetToken.token == token,
            PasswordResetToken.used == False,
            PasswordResetToken.expires_at > datetime.utcnow()
        ).first()
        
        if not reset_token:
            return jsonify({'error': 'Invalid or expired token'}), 400
        
        user = user_service.get_user_by_id(db, reset_token.user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Validate and hash new password
        valid, msg = user_service._validate_password_strength(new_password)
        if not valid:
            return jsonify({'error': msg}), 400
        
        user.password_hash = password_manager.hash_password(new_password)
        reset_token.used = True
        db.commit()
        
        logger.info(f"Password reset completed: {user.username}")
        return jsonify({'message': 'Password reset successfully'}), 200
    except Exception as e:
        logger.error(f"Password reset error: {e}")
        return jsonify({'error': 'Reset failed'}), 500
    finally:
        db.close()
