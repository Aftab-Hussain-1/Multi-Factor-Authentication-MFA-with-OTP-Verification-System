# type: ignore
"""User profile and account management routes"""
import logging
from flask import Blueprint, request, jsonify, session
from database import SessionLocal
from app.services.user_service import user_service
from functools import wraps

user_bp = Blueprint('user', __name__)
logger = logging.getLogger(__name__)


def require_login(f):
    """Decorator to protect routes requiring authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Not authenticated'}), 401
        return f(*args, **kwargs)
    return decorated_function


@user_bp.route('/api/user-info', methods=['GET'])
@require_login
def api_user_info():
    """Get current user info (requires authentication)"""
    db = SessionLocal()
    try:
        user = user_service.get_user_by_id(db, session['user_id'])
        if not user:
            return jsonify({'error': 'User not found'}), 404
        return jsonify(user.to_dict()), 200
    except Exception as e:
        logger.error(f"User info error: {e}")
        return jsonify({'error': 'Failed to retrieve user info'}), 500
    finally:
        db.close()


@user_bp.route('/api/change-password', methods=['POST'])
@require_login
def api_change_password():
    """Change password (requires authentication)"""
    data = request.json or {}
    old_password = data.get('old_password', '')
    new_password = data.get('new_password', '')
    
    if not old_password or not new_password:
        return jsonify({'error': 'Both passwords required'}), 400
    
    db = SessionLocal()
    try:
        user = user_service.get_user_by_id(db, session['user_id'])
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        success, message = user_service.change_password(db, user, old_password, new_password)
        if not success:
            return jsonify({'error': message}), 400
        
        logger.info(f"User changed password: {user.username}")
        return jsonify({'message': message}), 200
    except Exception as e:
        logger.error(f"Password change error: {e}")
        return jsonify({'error': 'Password change failed'}), 500
    finally:
        db.close()
