# type: ignore
"""Two-Factor Authentication routes"""
import logging
from flask import Blueprint, request, jsonify, session
from database import SessionLocal
from app.services.user_service import user_service
from app.services.two_factor_service import two_factor_service
from app.models import TwoFactorToken
from functools import wraps

twofa_bp = Blueprint('twofa', __name__)
logger = logging.getLogger(__name__)


def require_login(f):
    """Decorator to protect routes requiring authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Not authenticated'}), 401
        return f(*args, **kwargs)
    return decorated_function


@twofa_bp.route('/api/2fa/setup', methods=['POST'])
@require_login
def api_2fa_setup():
    """Setup 2FA for user"""
    db = SessionLocal()
    try:
        user = user_service.get_user_by_id(db, session['user_id'])
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        secret = two_factor_service.generate_secret()
        qr_code = two_factor_service.generate_qr_code(secret, user.email)
        backup_codes = two_factor_service.generate_backup_codes()
        
        return jsonify({
            'secret': secret,
            'qr_code': qr_code,
            'backup_codes': backup_codes
        }), 200
    except Exception as e:
        logger.error(f"2FA setup error: {e}")
        return jsonify({'error': '2FA setup failed'}), 500
    finally:
        db.close()


@twofa_bp.route('/api/2fa/enable', methods=['POST'])
@require_login
def api_2fa_enable():
    """Enable 2FA with verification"""
    data = request.json or {}
    secret = data.get('secret', '')
    token = data.get('token', '')
    backup_codes = data.get('backup_codes', [])
    
    if not secret or not token:
        return jsonify({'error': 'Secret and token required'}), 400
    
    db = SessionLocal()
    try:
        if not two_factor_service.verify_token(secret, token):
            return jsonify({'error': 'Invalid token'}), 400
        
        user = user_service.get_user_by_id(db, session['user_id'])
        twofa = TwoFactorToken(user_id=user.id, secret=secret, is_enabled=True, backup_codes=','.join(backup_codes))
        db.add(twofa)
        db.commit()
        
        logger.info(f"2FA enabled: {user.username}")
        return jsonify({'message': '2FA enabled successfully'}), 200
    except Exception as e:
        logger.error(f"2FA enable error: {e}")
        return jsonify({'error': '2FA setup failed'}), 500
    finally:
        db.close()


@twofa_bp.route('/api/2fa/verify', methods=['POST'])
def api_2fa_verify():
    """Verify 2FA token during login"""
    data = request.json or {}
    token = data.get('token', '')
    
    if 'pre_auth_user_id' not in session:
        return jsonify({'error': 'No pending authentication'}), 401
    
    if not token:
        return jsonify({'error': 'Token required'}), 400
    
    db = SessionLocal()
    try:
        user_id = session['pre_auth_user_id']
        user = user_service.get_user_by_id(db, user_id)
        
        twofa = db.query(TwoFactorToken).filter(TwoFactorToken.user_id == user.id).first()
        if not twofa or not twofa.is_enabled:
            return jsonify({'error': '2FA not enabled'}), 400
        
        if not two_factor_service.verify_token(twofa.secret, token):
            return jsonify({'error': 'Invalid 2FA token'}), 401
        
        session.permanent = True
        session['user_id'] = user_id
        session['username'] = session.pop('pre_auth_username')
        session.pop('pre_auth_user_id', None)
        
        logger.info(f"2FA verification successful: {user.username}")
        return jsonify({'message': 'Authentication successful', 'user': user.to_dict()}), 200
    except Exception as e:
        logger.error(f"2FA verify error: {e}")
        return jsonify({'error': '2FA verification failed'}), 500
    finally:
        db.close()
