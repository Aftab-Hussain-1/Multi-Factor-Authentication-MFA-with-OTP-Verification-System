# SQLAlchemy database engine with connection pooling
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import QueuePool
from config import Config

# Database engine (SQLite - file based, no server needed)
database_url = Config.DATABASE_URL
if 'sqlite' in database_url:
    # SQLite doesn't use connection pooling
    engine = create_engine(
        database_url,
        connect_args={'check_same_thread': False},
        echo=False
    )
else:
    # PostgreSQL with psycopg3 driver
    database_url = database_url.replace('postgresql://', 'postgresql+psycopg://')
    engine = create_engine(
        database_url,
        poolclass=QueuePool,
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,
        echo=False
    )

# Session factory and ORM base
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

Base = declarative_base()


def get_db():
    # Get database session
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    # Create database schema
    Base.metadata.create_all(bind=engine)


def drop_db():
    # Drop all tables
    Base.metadata.drop_all(bind=engine)
