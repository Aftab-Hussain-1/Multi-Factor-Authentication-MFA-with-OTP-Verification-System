#!/usr/bin/env python3
# type: ignore
"""Flask application entry point"""
import os
import logging
from database import init_db
from app import create_app

# Configure logging
logging.basicConfig(
    level=os.getenv('LOG_LEVEL', 'INFO'),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


if __name__ == '__main__':
    # Initialize database
    try:
        init_db()
        logger.info("Database initialized")
    except Exception as e:
        logger.error(f"Database initialization error: {e}")
    
    # Create Flask app
    app = create_app()
    
    # Run development server
    debug = os.getenv('FLASK_ENV') == 'development'
    port = int(os.getenv('PORT', 5001))
    host = os.getenv('HOST', '0.0.0.0')
    
    logger.info(f"Starting Flask server on {host}:{port} (debug={debug})")
    app.run(debug=debug, host=host, port=port, use_reloader=False)
