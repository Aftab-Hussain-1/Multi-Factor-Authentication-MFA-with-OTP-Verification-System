import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    # App configuration from .env
    DATABASE_URL = os.getenv(
        'DATABASE_URL',
        'sqlite:///./login.db'
    )
    ARGON2_TIME_COST = int(os.getenv('ARGON2_TIME_COST', '2'))
    ARGON2_MEMORY_COST = int(os.getenv('ARGON2_MEMORY_COST', '65536'))
    ARGON2_PARALLELISM = int(os.getenv('ARGON2_PARALLELISM', '1'))
    SECRET_KEY = os.getenv('SECRET_KEY', 'change-me-in-production')
    MIN_PASSWORD_LENGTH = 8
    REQUIRE_UPPERCASE = True
    REQUIRE_LOWERCASE = True
    REQUIRE_DIGITS = True
    REQUIRE_SPECIAL_CHARS = True
